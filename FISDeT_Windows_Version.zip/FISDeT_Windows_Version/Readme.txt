How to do:

--Windows--
1 - Extract archive
2 - Click to directory dist
3 - Find FISDeT.exe
4 - Run 
5 - Enjoy

--OSX--
1 - Click FISDeT icon to run
2 - Enjoy

--Linux--
1 - Extract archive
2 - Click to directory build --> exe.linux-x86_64-2.7
3 - Find FISDeT
4 - Run 
5 - Enjoy 