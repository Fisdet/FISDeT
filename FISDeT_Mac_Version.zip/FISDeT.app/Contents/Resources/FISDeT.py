__author__ = 'Pasquadibisceglie-Zaza'

from math import *
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from multiprocessing import Pool
from PyQt4 import QtCore, QtGui
import sys, time
from multiprocessing import Pool
import FileDialog
from scipy.stats import norm
import matplotlib as plt
import matplotlib as plt2

import numpy as np
import sip

from inputVariable2 import *

app=QtGui.QApplication(sys.argv)
logoint=QtGui.QIcon("img/LogoInt.png")
app.setWindowIcon(logoint)



inc=QRegExp()
inc.setPattern("^[A-Za-z0-9_]*$")
valida=QtGui.QRegExpValidator(inc)

inc2=QRegExp()
inc2.setPattern("^[0-9.-]*$")
valida2=QtGui.QRegExpValidator(inc2)

#Menu interface
menu = QtGui.QWidget()
menu.resize(650,370)
menu.setFixedSize(650,370)
menu.setStyleSheet('background-color: rgb(241,241,241); color: rgb(61,78,121);font:15px')
menu.setWindowTitle("Fuzzy Inference Development Tool")

frameMenu = QtGui.QGroupBox(menu)
frameMenu.setGeometry(15, 10, 300, 240)
frameMenu.setTitle("Create")
frameMenu.setStyleSheet('color: rgb(61,78,121);font:15px')

frameMenu2 = QtGui.QGroupBox(menu)
frameMenu2.setGeometry(330, 250, 300, 100)
frameMenu2.setTitle("Test")
frameMenu2.setStyleSheet('color: rgb(61,78,121);font:15px')

frameMenu3 = QtGui.QGroupBox(menu)
frameMenu3.setGeometry(330, 10, 300, 120)
frameMenu3.setTitle("View")
frameMenu3.setStyleSheet('color: rgb(61,78,121);font:15px')

frameMenu4 = QtGui.QGroupBox(menu)
frameMenu4.setGeometry(330, 140, 300, 100)
frameMenu4.setTitle("Save")
frameMenu4.setStyleSheet('color: rgb(61,78,121);font:15px')

frameMenu5 = QtGui.QGroupBox(menu)
frameMenu5.setGeometry(15, 250, 300, 100)
frameMenu5.setTitle("Import")
frameMenu5.setStyleSheet('color: rgb(61,78,121);font:15px')

picR_1 = QtGui.QLabel(menu)
picR_1.setGeometry(30, 0, 400, 100)
picG_1 = QtGui.QLabel(menu)
picG_1.setGeometry(30, 0, 400, 100)
picR_1.setPixmap(QtGui.QPixmap("img/Red.png"))
picG_1.setPixmap(QtGui.QPixmap("img/Green.png"))
picR_1.setGeometry(25, 67, 24, 24)
picG_1.setGeometry(25, 67, 24, 24)
picG_1.setVisible(False)
picR_1.setStyleSheet('background-color: rgb(231,231,231);')
picG_1.setStyleSheet('background-color: rgb(231,231,231);')

picR_2 = QtGui.QLabel(menu)
picR_2.setGeometry(30, 0, 400, 100)
picG_2 = QtGui.QLabel(menu)
picG_2.setGeometry(30, 0, 400, 100)
picR_2.setPixmap(QtGui.QPixmap("img/Red.png"))
picG_2.setPixmap(QtGui.QPixmap("img/Green.png"))
picR_2.setGeometry(25, 137, 24, 24)
picG_2.setGeometry(25, 137, 24, 24)
picG_2.setVisible(False)
picR_2.setStyleSheet('background-color: rgb(231,231,231);')
picG_2.setStyleSheet('background-color: rgb(231,231,231);')

picR_3 = QtGui.QLabel(menu)
picR_3.setGeometry(30, 0, 400, 100)
picG_3 = QtGui.QLabel(menu)
picG_3.setGeometry(30, 0, 400, 100)
picR_3.setPixmap(QtGui.QPixmap("img/Red.png"))
picG_3.setPixmap(QtGui.QPixmap("img/Green.png"))
picR_3.setGeometry(25, 207, 24, 24)
picG_3.setGeometry(25, 207, 24, 24)
picG_3.setVisible(False)
picR_3.setStyleSheet('background-color: rgb(231,231,231);')
picG_3.setStyleSheet('background-color: rgb(231,231,231);')

picR_4 = QtGui.QLabel(menu)
picR_4.setGeometry(350, 0, 400, 100)
picG_4 = QtGui.QLabel(menu)
picG_4.setGeometry(350, 0, 400, 100)
picR_4.setPixmap(QtGui.QPixmap("img/Red.png"))
picG_4.setPixmap(QtGui.QPixmap("img/Green.png"))
picR_4.setGeometry(345, 187, 24, 24)
picG_4.setGeometry(345, 187, 24, 24)
picG_4.setVisible(False)
picR_4.setStyleSheet('background-color: rgb(231,231,231);')
picG_4.setStyleSheet('background-color: rgb(231,231,231);')

picR_6 = QtGui.QLabel(menu)
picR_6.setGeometry(350, 0, 400, 100)
picG_6 = QtGui.QLabel(menu)
picG_6.setGeometry(350, 0, 400, 100)
picR_6.setPixmap(QtGui.QPixmap("img/Red.png"))
picG_6.setPixmap(QtGui.QPixmap("img/Green.png"))
picR_6.setGeometry(345, 297, 24, 24)
picG_6.setGeometry(345, 297, 24, 24)
picG_6.setVisible(False)
picR_6.setStyleSheet('background-color: rgb(231,231,231);')
picG_6.setStyleSheet('background-color: rgb(231,231,231);')

tastoInput = QtGui.QPushButton(menu)
tastoInput.setIconSize(QtCore.QSize(64, 64))
tastoInput.setGeometry(60, 60, 220, 31)
tastoInput.setText("STEP 1: CREATION OF INPUT VARIABLES")
tastoInput.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255); font:10px')

tastoOutput = QtGui.QPushButton(menu)
tastoOutput.setIconSize(QtCore.QSize(64, 64))
tastoOutput.setGeometry(60, 130, 220, 31)
tastoOutput.setText("STEP 2: CREATION OF OUTPUT VARIABLES")
tastoOutput.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);font:10px')

tastoRegole = QtGui.QPushButton(menu)
tastoRegole.setIconSize(QtCore.QSize(64, 64))
tastoRegole.setGeometry(60, 200, 220, 31)
tastoRegole.setText("STEP 3: CREATION OF RULES")
tastoRegole.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);font:10px')

tastoRew = QtGui.QPushButton(menu)
tastoRew.setIconSize(QtCore.QSize(64, 64))
tastoRew.setGeometry(380, 60, 220, 31)
tastoRew.setText("VIEW FUZZY SYSTEM")
tastoRew.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);font:10px')

tastoFcl = QtGui.QPushButton(menu)
tastoFcl.setIconSize(QtCore.QSize(64, 64))
tastoFcl.setGeometry(380, 180, 220, 31)
tastoFcl.setText("SAVE FUZZY SYSTEM")
tastoFcl.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);font:10px')


tastoTest = QtGui.QPushButton(menu)
tastoTest.setIconSize(QtCore.QSize(64, 64))
tastoTest.setGeometry(380, 290, 220, 31)
tastoTest.setText("TEST")
tastoTest.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);font:10px')

tastoImport = QtGui.QPushButton(menu)
tastoImport.setIconSize(QtCore.QSize(64, 64))
tastoImport.setGeometry(60, 290, 220, 31)
tastoImport.setText("IMPORT SYSTEM")
tastoImport.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);font:10px')

#first input interface
widget = QtGui.QWidget()
widget.resize(420, 190)
widget.setWindowTitle("Fuzzy Inference Development Tool")
widget.setStyleSheet('background-color: rgb(241,241,241);')
widget.setFixedSize(420,190)

labelInfo = QtGui.QLabel(widget)
labelInfo.setStyleSheet('color: rgb(137,20,37);font:15px')
labelInfo.setGeometry(70, 5, 400, 51)
labelInfo.setText("STEP 1: CREATION OF INPUT VARIABLES ")

msg = QtGui.QMessageBox()
msg.resize(141,71)
msg.setWindowIcon(logoint)
msg.setWindowTitle("FISDeT")
msg.setStyleSheet('background-color: rgb(241,241,241);color: rgb(61,78,121);font:15px')

labelI = QtGui.QLabel(widget)
labelI.setStyleSheet('color: rgb(61,78,121); background-color: rgb(241,241,241); font:15px')
labelI.setGeometry(90, 50, 230, 51)
labelI.setText("CREATE NEW INPUT VARIABLE")

tastoPiu = QtGui.QPushButton(widget)
tastoPiu.setIconSize(QtCore.QSize(64, 64))
tastoPiu.setGeometry(335, 63, 24, 24)
tastoPiu.setText("+")
tastoPiu.setStyleSheet('color:rgb(255,255,255) ; background-color: rgb(61,78,121);font:15px')

tastoMenu = QtGui.QPushButton(widget)
tastoMenu.setIconSize(QtCore.QSize(64, 64))
tastoMenu.setGeometry(220, 120, 101, 31)
tastoMenu.setText("MENU")
tastoMenu.setStyleSheet('background-color: rgb(61,78,121); color: rgb(255,255,255);')

tastoViewTab = QtGui.QPushButton(widget)
tastoViewTab.setIconSize(QtCore.QSize(64, 64))
tastoViewTab.setGeometry(90, 120, 111, 31)
tastoViewTab.setText("VIEW VARIABLES")
tastoViewTab.setStyleSheet('background-color: rgb(61,78,121); color: rgb(255,255,255);')

#second input interface
widget2 = QtGui.QWidget()
widget2.resize(672, 530)
widget2.setWindowTitle('Fuzzy Inference Development Tool')
widget2.setStyleSheet('background-color: rgb(241,241,241);')
widget2.setFixedSize(672,530)

labelInfo2 = QtGui.QLabel(widget2)
labelInfo2.setStyleSheet('color: rgb(137,20,37);font:15px')
labelInfo2.setGeometry(210, -12, 400, 51)
labelInfo2.setText("STEP 1: CREATION OF INPUT VARIABLES")

frameVar = QtGui.QGroupBox(widget2)
frameVar.setGeometry(10, 20, 650, 100)
frameVar.setTitle("Variable")
frameVar.setStyleSheet('background-color: rgb(241,241,241); color: rgb(61,78,121);font:15px')

labelNome = QtGui.QLabel(widget2)
labelNome.setGeometry(20, 60, 50, 31)
labelNome.setText("NAME:")
labelNome.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')
nomeVar = QtGui.QLineEdit(widget2)
nomeVar.setGeometry(85, 60, 90, 21)
nomeVar.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
nomeVar.setValidator(valida)


labelInfoDom = QtGui.QLabel(widget2)
labelInfoDom.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')
labelInfoDom.setGeometry(350, 60, 70, 31)
labelInfoDom.setText("Es. 0-100")

labelDom = QtGui.QLabel(widget2)
labelDom.setGeometry(200, 60, 121, 31)
labelDom.setText("DOMAIN:")
labelDom.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')

domX = QtGui.QLineEdit(widget2)
domX.setGeometry(265, 60, 35, 21)
domX.setValidator(valida2)
domX.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
domY = QtGui.QLineEdit(widget2)
domY.setGeometry(310, 60, 35, 21)
domY.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
domY.setValidator(valida2)


frameTerm = QtGui.QGroupBox(widget2)
frameTerm.setGeometry(10, 120, 650, 360)
frameTerm.setTitle("Term")
frameTerm.setStyleSheet('background-color: rgb(241,241,241); color: rgb(61,78,121);font:15px')

boxGrafico=QGraphicsView(widget2)
boxGrafico.setGeometry(15, 230, 510, 200)
boxGrafico.setStyleSheet('background-color: rgb(255,255,255);')

labelFunz = QtGui.QLabel(widget2)
labelFunz.setStyleSheet('color: rgb(61,78,121);')
labelFunz.setGeometry(430, 60, 121, 31)
labelFunz.setText("FUNCTION:")
labelFunz.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')

funz_layout = QtGui.QButtonGroup(widget2)

chkTriangolo = QtGui.QRadioButton(widget2)
chkTriangolo.setGeometry(520, 50, 141, 21)
chkTriangolo.setText("TRIANGULAR")
chkTriangolo.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')
chkTriangolo.setChecked(False)

chkGauss = QtGui.QRadioButton(widget2)
chkGauss.setGeometry(520, 70, 141, 21)
chkGauss.setText("GAUSSIAN")
chkGauss.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')

chkTrap = QtGui.QRadioButton(widget2)
chkTrap.setGeometry(520, 90, 141, 21)
chkTrap.setText("TRAPEZOIDAL")
chkTrap.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')

funz_layout.addButton(chkTriangolo)
funz_layout.addButton(chkGauss)
funz_layout.addButton(chkTrap)

tastoAzz = QtGui.QPushButton(widget2)
tastoAzz.setIconSize(QtCore.QSize(64, 64))
iconaPiu=QtGui.QIcon("img/TastoPiu.png")
tastoAzz.setIcon(iconaPiu)
tastoAzz.setGeometry(500, 160, 24, 24)
tastoAzz.setVisible(False)
tastoAzz.setStyleSheet('color: rgb(255,255,255); background-color: rgb(61,78,121);')

tastoAzz2 = QtGui.QPushButton(widget2)
tastoAzz2.setIconSize(QtCore.QSize(64, 64))
tastoAzz2.setGeometry(500, 160, 24, 24)
tastoAzz2.setVisible(False)
tastoAzz2.setStyleSheet('color: rgb(255,255,255); background-color: rgb(61,78,121);')
iconaApply=QtGui.QIcon("img/Apply.png")
tastoAzz2.setIcon(iconaPiu)
tastoAzz2.setVisible(False)

labelInfoTab = QtGui.QLabel(widget2)
labelInfoTab.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')
labelInfoTab.setGeometry(150, 160, 80, 31)
labelInfoTab.setText("LABEL:")

labelAddTerm = QtGui.QLabel(widget2)
labelAddTerm.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')
labelAddTerm.setGeometry(390, 160, 94, 31)
labelAddTerm.setText("ADD TERM:")

c = 0
NomeFuzzy = QtGui.QLineEdit(widget2)
NomeFuzzy.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
NomeFuzzy.setGeometry(210, 150, 157, 21)
NomeFuzzy.setValidator(valida)
R1 = QtGui.QLineEdit(widget2)
R1.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
R1.setGeometry(210 + c, 180, 35, 21)
c = c + 40
R2 = QtGui.QLineEdit(widget2)
R2.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
R2.setGeometry(210 + c, 180, 35, 21)
c = c + 40
R3 = QtGui.QLineEdit(widget2)
R3.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
R3.setGeometry(210 + c, 180, 35, 21)
c = c + 40
R4 = QtGui.QLineEdit(widget2)
R4.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
R4.setGeometry(210 + c, 180, 35, 21)
R1.setValidator(valida2)
R2.setValidator(valida2)
R3.setValidator(valida2)
R4.setValidator(valida2)

NomeFuzzy.setVisible(False)
R1.setVisible(False)
R2.setVisible(False)
R3.setVisible(False)
R4.setVisible(False)

tastoAgg = QtGui.QPushButton(widget2)
tastoAgg.setIconSize(QtCore.QSize(64, 64))
tastoAgg.setGeometry(310, 442, 24, 24)
iconaPiu=QtGui.QIcon("img/TastoPiu.png")
tastoAgg.setIcon(iconaPiu)

labelPiu= QtGui.QLabel(widget2)
labelPiu.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')
labelPiu.setGeometry(190, 438, 120, 38)
labelPiu.setText("ADD VARIABLE:")

tastoMod2 = QtGui.QPushButton(widget2)
tastoMod2.setIconSize(QtCore.QSize(64, 64))
tastoMod2.setGeometry(310, 442, 24, 24)
tastoMod2.setStyleSheet('color: rgb(255,255,255); background-color: rgb(61,78,121);')
tastoMod2.setVisible(False)
iconaApply=QtGui.QIcon("img/Apply.png")
tastoMod2.setIcon(iconaApply)

listaTerminiI = QtGui.QTableWidget(100,5,widget2)
listaTerminiI.setGeometry(540, 230, 100, 171)
listaTerminiI.horizontalHeader().hide()
listaTerminiI.verticalHeader().hide()
listaTerminiI.horizontalScrollBar().hide()
listaTerminiI.setShowGrid(False)
listaTerminiI.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
listaTerminiI.setStyleSheet('color: rgb(61,78,121);background-color: rgb(255,255,255);')
listaTerminiI.horizontalScrollBar().setDisabled(True)

tastoMenu2 = QtGui.QPushButton(widget2)
tastoMenu2.setIconSize(QtCore.QSize(64, 64))
tastoMenu2.setGeometry(555, 490, 101, 31)
tastoMenu2.setText("MENU")
tastoMenu2.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);')

tastoMod = QtGui.QPushButton(widget2)
tastoMod.setIconSize(QtCore.QSize(64, 64))
tastoMod.setGeometry(560, 407, 24, 24)
iconaMod=QtGui.QIcon("img/Mod.png")
tastoMod.setIcon(iconaMod)

tastoDelTerm = QtGui.QPushButton(widget2)
tastoDelTerm.setIconSize(QtCore.QSize(64, 64))
tastoDelTerm.setGeometry(595, 407, 24, 24)
iconaTrash=QtGui.QIcon("img/Trash.png")
tastoDelTerm.setIcon(iconaTrash)

#third input interface
widgetTabI = QtGui.QWidget()
widgetTabI.resize(190, 290)
widgetTabI.setFixedSize(190,290)
widgetTabI.setWindowTitle("Fuzzy Inference System Development Tool")
labelTab = QtGui.QLabel(widgetTabI)
labelTab.setStyleSheet('color: rgb(61,78,121);font:15px')
labelTab.setGeometry(30, 10, 400, 51)
labelTab.setText("INPUT VARIABLES")

tabellaI = QtGui.QTableWidget(100,1,widgetTabI)
tabellaI.setGeometry(45, 51, 100, 141)
tabellaI.horizontalHeader().hide()
tabellaI.verticalHeader().hide()
tabellaI.horizontalScrollBar().hide()
tabellaI.setShowGrid(False)
tabellaI.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
tabellaI.setStyleSheet('color: rgb(61,78,121);background-color: rgb(255,255,255);')

tastoModI = QtGui.QPushButton(widgetTabI)
tastoModI.setIconSize(QtCore.QSize(64, 64))
tastoModI.setGeometry(60, 225, 24, 24)
iconaMod=QtGui.QIcon("img/Mod.png")
tastoModI.setIcon(iconaMod)

tastoDelVarI = QtGui.QPushButton(widgetTabI)
tastoDelVarI.setIconSize(QtCore.QSize(64, 64))
tastoDelVarI.setGeometry(100, 225, 24 , 24)
iconaTrash=QtGui.QIcon("img/Trash.png")
tastoDelVarI.setIcon(iconaTrash)

#output interface
widget3 = QtGui.QWidget()
widget3.resize(672, 565)
widget3.setWindowTitle('Fuzzy Inference System Development Tool')
widget3.setStyleSheet('background-color: rgb(241,241,241);')
widget3.setFixedSize(672,565)

labelInfo2 = QtGui.QLabel(widget3)
labelInfo2.setStyleSheet('color: rgb(137,20,37);font:15px')
labelInfo2.setGeometry(190, -10, 400, 51)
labelInfo2.setText("STEP 2: CREATION OF OUTPUT VARIABLE")

frameVar = QtGui.QGroupBox(widget3)
frameVar.setGeometry(10, 30, 650, 100)
frameVar.setTitle("Variable")
frameVar.setStyleSheet('background-color: rgb(241,241,241); color: rgb(61,78,121);font:15px')

labelNome = QtGui.QLabel(widget3)
labelNome.setStyleSheet('color: rgb(61,78,121);')
labelNome.setGeometry(20, 70, 50, 31)
labelNome.setText("NAME:")
labelNome.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')
nomeVar3 = QtGui.QLineEdit(widget3)
nomeVar3.setGeometry(85, 70, 90, 21)
nomeVar3.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
nomeVar3.setValidator(valida)
chkclass=QtGui.QCheckBox(widget3)
chkclass.setGeometry(20, 100, 98, 21)
chkclass.setText("Classification")
chkclass.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')

labelInfoDom = QtGui.QLabel(widget3)
labelInfoDom.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')
labelInfoDom.setGeometry(370, 70, 70, 31)
labelInfoDom.setText("Es. 0-100")

labelDom = QtGui.QLabel(widget3)
labelDom.setGeometry(200, 70, 121, 31)
labelDom.setText("DOMAIN:")
labelDom.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')

domX3 = QtGui.QLineEdit(widget3)
domX3.setGeometry(270, 70, 35, 21)
domX3.setValidator(valida2)
domX3.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
domY3 = QtGui.QLineEdit(widget3)
domY3.setGeometry(320, 70, 35, 21)
domY3.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
domY3.setValidator(valida2)

frameTerm2 = QtGui.QGroupBox(widget3)
frameTerm2.setGeometry(10, 130, 650, 385)
frameTerm2.setTitle("Term")
frameTerm2.setStyleSheet('background-color: rgb(241,241,241); color: rgb(61,78,121);font:15px')

labelDefuzzy = QtGui.QLabel(widget3)
labelDefuzzy.setStyleSheet('color: rgb(61,78,121);')
labelDefuzzy.setGeometry(520, 154, 121, 31)
labelDefuzzy.setText("DEFUZZIFICATION \nMETHOD:")
labelDefuzzy.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')

comboDefuzzy = QtGui.QComboBox(widget3)
comboDefuzzy.setGeometry(520,190,121,31)
comboDefuzzy.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')

labelAccu = QtGui.QLabel(widget3)
labelAccu.setStyleSheet('color: rgb(61,78,121);')
labelAccu.setGeometry(520, 154, 121, 31)
labelAccu.setText("ACCUMULATION \nMETHOD:")
labelAccu.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')
labelAccu.setVisible(False)

comboAccu = QtGui.QComboBox(widget3)
comboAccu.setGeometry(520,190,121,31)
comboAccu.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
comboAccu.addItem("MAX")
comboAccu.addItem("BSUM")
comboAccu.setVisible(False)

labelFunz = QtGui.QLabel(widget3)
labelFunz.setStyleSheet('color: rgb(61,78,121);')
labelFunz.setGeometry(445, 70, 121, 31)
labelFunz.setText("FUNCTION:")
labelFunz.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')

chkTriangolo3 = QtGui.QRadioButton(widget3)
chkTriangolo3.setGeometry(520, 48, 141, 21)
chkTriangolo3.setText("TRIANGULAR")
chkTriangolo3.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')
chkTriangolo3.setChecked(False)

chkGauss3 = QtGui.QRadioButton(widget3)
chkGauss3.setGeometry(520, 68, 141, 21)
chkGauss3.setText("GAUSSIAN")
chkGauss3.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')

chkTrap3 = QtGui.QRadioButton(widget3)
chkTrap3.setGeometry(520, 88, 141, 21)
chkTrap3.setText("TRAPEZOIDAL")
chkTrap3.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')

chkSing3 = QtGui.QRadioButton(widget3)
chkSing3.setGeometry(520, 108, 141, 21)
chkSing3.setText("SINGLETON")
chkSing3.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')

funz_layout3 = QtGui.QButtonGroup(widget3)
funz_layout3.addButton(chkGauss3)
funz_layout3.addButton(chkTriangolo3)
funz_layout3.addButton(chkTrap3)
funz_layout3.addButton(chkSing3)

tastoMenu3 = QtGui.QPushButton(widget3)
tastoMenu3.setIconSize(QtCore.QSize(64, 64))
tastoMenu3.setGeometry(555, 525, 101, 31)
tastoMenu3.setText("MENU")
tastoMenu3.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);')

tastoAgg3 = QtGui.QPushButton(widget3)
#tastoAgg3.setIconSize(QtCore.QSize(24, 24))
tastoAgg3.setGeometry(240, 475, 121, 24)
tastoAgg3.setText("SAVE VARIABLE")
tastoAgg3.setStyleSheet('color: rgb(255,255,255); background-color: rgb(61,78,121);')

"""
labelPiu3= QtGui.QLabel(widget3)
labelPiu3.setStyleSheet('background-color: rgb(241,241,241); color: rgb(61,78,121);')
labelPiu3.setGeometry(170, 470, 120, 38)
labelPiu3.setText("SAVE VARIABLE:")
"""

tastoAzz3 = QtGui.QPushButton(widget3)
tastoAzz3.setIconSize(QtCore.QSize(64, 64))
tastoAzz3.setGeometry(390, 170, 24, 24)
tastoAzz3.setIcon(iconaPiu)
tastoAzz3.setVisible(False)
tastoAzz3.setStyleSheet('color: rgb(255,255,255); background-color: rgb(61,78,121);')

tastoAzz3Class = QtGui.QPushButton(widget3)
tastoAzz3Class.setIconSize(QtCore.QSize(64, 64))
tastoAzz3Class.setGeometry(390, 170, 24, 24)
tastoAzz3Class.setIcon(iconaPiu)
tastoAzz3Class.setVisible(False)
tastoAzz3Class.setStyleSheet('color: rgb(255,255,255); background-color: rgb(61,78,121);')

tastoDelTermOClass = QtGui.QPushButton(widget3)
tastoDelTermOClass.setIconSize(QtCore.QSize(64, 64))
tastoDelTermOClass.setGeometry(590, 435, 24, 24)
tastoDelTermOClass.setIcon(iconaTrash)

tastoModTermOClass = QtGui.QPushButton(widget3)
tastoModTermOClass.setIconSize(QtCore.QSize(64, 64))
tastoModTermOClass.setGeometry(560, 435, 24, 24)
tastoModTermOClass.setIcon(iconaMod)

labelAddTerm3= QtGui.QLabel(widget3)
labelAddTerm3.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')
labelAddTerm3.setGeometry(290, 170, 90, 38)
labelAddTerm3.setText("ADD TERM:")

tastoAzz3_2 = QtGui.QPushButton(widget3)
tastoAzz3_2.setIconSize(QtCore.QSize(64, 64))
tastoAzz3_2.setGeometry(390, 170, 24, 24)
tastoAzz3_2.setIcon(iconaPiu)
tastoAzz3_2.setVisible(False)
tastoAzz3_2.setStyleSheet('color: rgb(255,255,255); background-color: rgb(61,78,121);')

labelInfoTab = QtGui.QLabel(widget3)
labelInfoTab.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')
labelInfoTab.setGeometry(25, 170, 80, 31)
labelInfoTab.setText("LABEL:")

c = 0
NomeFuzzy3 = QtGui.QLineEdit(widget3)
NomeFuzzy3.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
NomeFuzzy3.setGeometry(85, 160, 157, 21)
NomeFuzzy3.setValidator(valida)
R1_3 = QtGui.QLineEdit(widget3)
R1_3.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
R1_3.setGeometry(85 + c, 190, 35, 21)
c = c + 40
R2_3 = QtGui.QLineEdit(widget3)
R2_3.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
R2_3.setGeometry(85 + c, 190, 35, 21)
c = c + 40
R3_3 = QtGui.QLineEdit(widget3)
R3_3.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
R3_3.setGeometry(85 + c, 190, 35, 21)
c = c + 40
R4_3 = QtGui.QLineEdit(widget3)
R4_3.setStyleSheet('background-color: rgb(255,255,255); color: rgb(61,78,121);')
R4_3.setGeometry(85 + c, 190, 35, 21)
R1_3.setValidator(valida2)
R2_3.setValidator(valida2)
R3_3.setValidator(valida2)
R4_3.setValidator(valida2)

NomeFuzzy3.setVisible(False)
R1_3.setVisible(False)
R2_3.setVisible(False)
R3_3.setVisible(False)
R4_3.setVisible(False)


labelNumClass = QtGui.QLabel(widget3)
labelNumClass.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')
labelNumClass.setGeometry(180, 250, 141, 31)
labelNumClass.setText("NUMBER OF CLASSES:")
labelNumClass.setVisible(False)

labelNum = QtGui.QLabel(widget3)
labelNum.setStyleSheet('background-color: rgb(231,231,231); color: rgb(61,78,121);')
labelNum.setGeometry(340, 255, 21, 21)
labelNum.setText(" 0 ")
labelNum.setVisible(False)

boxGrafico2=QGraphicsView(widget3)
boxGrafico2.setGeometry(15, 260, 510, 200)
boxGrafico2.setStyleSheet('background-color: rgb(255,255,255);')

tabellaO = QtGui.QTableWidget(100,5,widget3)
tabellaO.setGeometry(540, 260, 100, 171)
tabellaO.horizontalHeader().hide()
tabellaO.verticalHeader().hide()
tabellaO.horizontalScrollBar().hide()
tabellaO.setShowGrid(False)
tabellaO.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
tabellaO.setStyleSheet('color: rgb(61,78,121);background-color: rgb(255,255,255);')
tabellaO.horizontalScrollBar().setDisabled(True)
tastoDelTermO = QtGui.QPushButton(widget3)
tastoDelTermO.setIconSize(QtCore.QSize(64, 64))
tastoDelTermO.setGeometry(590, 435, 24, 24)
tastoDelTermO.setIcon(iconaTrash)

tastoModTermO = QtGui.QPushButton(widget3)
tastoModTermO.setIconSize(QtCore.QSize(64, 64))
tastoModTermO.setGeometry(560, 435, 24, 24)
tastoModTermO.setIcon(iconaMod)

#rule interface
widget4 = QtGui.QWidget()
widget4.resize(942, 375)
widget4.setWindowTitle('Fuzzy Inference System Development Tool')
widget4.setStyleSheet('background-color: rgb(241,241,241);')
widget4.setFixedSize(942,375)

labelInfo4 = QtGui.QLabel(widget4)
labelInfo4.setStyleSheet('color: rgb(137,20,37);font:15px')
labelInfo4.setGeometry(320, -10, 400, 51)
labelInfo4.setText("STEP 3: CREATION OF RULES")

frameReg = QtGui.QGroupBox(widget4)
frameReg.setGeometry(8, 30, 920, 300)
frameReg.setTitle("NEW RULE")
frameReg.setStyleSheet('color: rgb(61,78,121);font:15px')

tastoAggiungiR = QtGui.QPushButton(widget4)
tastoAggiungiR.setIconSize(QtCore.QSize(64, 64))
tastoAggiungiR.setGeometry(870, 82, 24, 24)
tastoAggiungiR.setText("+")
tastoAggiungiR.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);')

listReg = QtGui.QListWidget(widget4)
listReg.setGeometry(20, 165, 890, 101)
listReg.setStyleSheet('background-color: rgb(241,241,241); color: rgb(61,78,121);font:12px')
listReg.setStyleSheet('color: rgb(61,78,121);background-color: rgb(255,255,255);')

tastoDel5 = QtGui.QPushButton(widget4)
tastoDel5.setIconSize(QtCore.QSize(64, 64))
tastoDel5.setGeometry(390, 280, 121, 31)
tastoDel5.setText("DELETE RULE")
tastoDel5.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);font:15px')

tastoMenu4 = QtGui.QPushButton(widget4)
tastoMenu4.setIconSize(QtCore.QSize(64, 64))
tastoMenu4.setGeometry(805, 335, 121, 31)
tastoMenu4.setText("MENU")
tastoMenu4.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);')

tabR=QtGui.QTableWidget(1,10,widget4)
tabR2=QtGui.QTableWidget(1,1,widget4)
tabR.setStyleSheet('color: rgb(61,78,121);background-color: rgb(255,255,255);')
tabR2.setStyleSheet('color: rgb(61,78,121);background-color: rgb(255,255,255);')

#inference interface
testWidget = QtGui.QWidget()
testWidget.setWindowTitle("Fuzzy Inference System Development Tool")
testWidget.resize(760, 550)
testWidget.setStyleSheet('background-color: rgb(241,241,241); color: rgb(61,78,121);font:15px')
testWidget.setFixedSize(760,550)

tastoMenuTest = QtGui.QPushButton(testWidget)
tastoMenuTest.setIconSize(QtCore.QSize(64, 64))
tastoMenuTest.setGeometry(650, 420, 75, 31)
tastoMenuTest.setText("MENU")
tastoMenuTest.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);font:15px')

tastoImportTest = QtGui.QPushButton(testWidget)
tastoImportTest.setIconSize(QtCore.QSize(64, 64))
tastoImportTest.setGeometry(585, 300, 121, 31)
tastoImportTest.setText("IMPORT DATA")
tastoImportTest.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);font:15px')

frameTestOut = QtGui.QGroupBox(testWidget)
frameTestOut.setGeometry(570, 10, 150, 160)
frameTestOut.setTitle("Output Variable")
frameTestOut.setStyleSheet('color: rgb(61,78,121);font:15px')
tabInfOut=QtGui.QTableWidget(1,1,testWidget)

frameApriTest = QtGui.QGroupBox(testWidget)
frameApriTest.setGeometry(50, 10, 500, 160)
frameApriTest.setTitle("Input Variables")
frameApriTest.setStyleSheet('color: rgb(61,78,121);font:15px')

frameRule = QtGui.QGroupBox(testWidget)
frameRule.setGeometry(50, 180, 500, 250)
frameRule.setTitle("Rule Membership")
frameRule.setStyleSheet('color: rgb(61,78,121);font:15px')

tastoRun = QtGui.QPushButton(testWidget)
tastoRun.setIconSize(QtCore.QSize(64, 64))
tastoRun.setGeometry(595, 240, 101, 31)
tastoRun.setText("INFERENCE")
tastoRun.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);font:15px')

frameDict = QtGui.QGroupBox(testWidget)
frameDict.setTitle("Classes Result of ")
frameDict.setGeometry(50, 440, 500, 140)
frameDict.setStyleSheet('color: rgb(61,78,121);font:15px')
frameDict.setVisible(False)

tabInfDict=QtGui.QTableWidget(1,0,testWidget)
tabInfDict.setGeometry(75,470,450,75)
tabInfDict.setStyleSheet('color: rgb(61,78,121);background-color: rgb(255,255,255);font:15px')
tabInfDict.verticalHeader().hide()
tabInfDict.horizontalHeader().setDefaultSectionSize(124)
tabInfDict.setVisible(False)

tabInf=QtGui.QTableWidget(1,10,testWidget)
tabInfReg=QtGui.QTableWidget(1,2,testWidget)

#review interface
widget5 = QtGui.QWidget()
widget5.resize(824, 620)
widget5.setWindowTitle('Fuzzy Inference System Development Tool')
widget5.setStyleSheet('background-color: rgb(241,241,241);')
widget5.setFixedSize(824,630)

frameWieI = QtGui.QGroupBox(widget5)
frameWieI.setGeometry(30, 10, 370, 240)
frameWieI.setTitle("VIEW INPUT VARIABLES")
frameWieI.setStyleSheet('color: rgb(61,78,121);font:15px')
listWvarI = QtGui.QListWidget(widget5)
listWvarI.setGeometry(44, 45, 341, 192)
listWvarI.setStyleSheet('background-color: rgb(241,241,241); color: rgb(61,78,121);font:12px')
listWvarI.setStyleSheet('color: rgb(61,78,121);background-color: rgb(255,255,255);')

frameWieO = QtGui.QGroupBox(widget5)
frameWieO.setGeometry(420, 10, 370, 240)
frameWieO.setTitle("VIEW OUTPUT VARIABLE")
frameWieO.setStyleSheet('color: rgb(61,78,121);font:15px')
listWvarO = QtGui.QListWidget(widget5)
listWvarO.setGeometry(435, 45, 341, 192)
listWvarO.setStyleSheet('background-color: rgb(241,241,241); color: rgb(61,78,121);font:12x')
listWvarO.setStyleSheet('color: rgb(61,78,121);background-color: rgb(255,255,255);')

frameWieI = QtGui.QGroupBox(widget5)
frameWieI.setGeometry(30, 305, 760, 280)
frameWieI.setTitle("VIEW FUZZY RULES")
frameWieI.setStyleSheet('color: rgb(61,78,121);font:15px')
listWReg = QtGui.QListWidget(widget5)
listWReg.setGeometry(80, 345, 661, 192)
listWReg.setStyleSheet('background-color: rgb(241,241,241); color: rgb(61,78,121);font:12px')
listWReg.setStyleSheet('color: rgb(61,78,121);background-color: rgb(255,255,255);')

tastoMenu5 = QtGui.QPushButton(widget5)
tastoMenu5.setIconSize(QtCore.QSize(64, 64))
tastoMenu5.setGeometry(685, 590, 101, 31)
tastoMenu5.setText("MENU")
tastoMenu5.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);font:15px')

tastoPlot5 = QtGui.QPushButton(widget5)
tastoPlot5.setIconSize(QtCore.QSize(64, 64))
tastoPlot5.setGeometry(350, 270, 131, 31)
tastoPlot5.setText("PLOT VARIABLES")
tastoPlot5.setStyleSheet('background-color: rgb(61,78,121);color: rgb(255,255,255);font:15px')
tastoPlot5.setVisible(False)


splash_pix = QtGui.QPixmap('img/splash.png')
splash = QSplashScreen(splash_pix, Qt.WindowStaysOnTopHint)
splash.setMask(splash_pix.mask())
splash.show()

"""

scene3 = QGraphicsScene()
scene3.addPixmap(QPixmap("img/splash.png"))
boxGrafico3=QGraphicsView()
#boxGrafico3.resize(672,573)
boxGrafico3.setGeometry(320,150,672,573)
boxGrafico3.setWindowFlags(Qt.FramelessWindowHint)
boxGrafico3.setScene(scene3)
boxGrafico3.show()
time.sleep(4)
boxGrafico3.close()
boxGrafico3.setVisible(False)

menu.show()
"""
import signal
import PyQt4.QtGui

def handleIntSignal(signum, frame):
    '''Ask app to close if Ctrl+C is pressed.'''
    PyQt4.QtGui.qApp.closeAllWindows()

signal.signal(signal.SIGINT, handleIntSignal)
time.sleep(4)
splash.finish(menu)


menu.sizeHint()
display=QtGui.QDesktopWidget()
base=display.width()
altezza=display.height()

baseMenu=menu.width()
altezzaMenu=menu.height()


cw = (base/2) - (baseMenu/2)
ch = (altezza/2) - (altezzaMenu/2)
menu.move(cw,ch)
menu.show()
app.processEvents()






